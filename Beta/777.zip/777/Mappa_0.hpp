//
// Created by Matteo Conti on 23/06/17.
//

#ifndef INC_777_MAPPA_0_HPP
#define INC_777_MAPPA_0_HPP


class Mappa_0 {

};


#endif //INC_777_MAPPA_0_HPP
