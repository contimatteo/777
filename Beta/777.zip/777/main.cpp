#include <iostream>
#include <SFML/Graphics.hpp>
#include "GestoreGioco.hpp"

using namespace sf;


int main(int argc, char** argv)
{
    //GestoreGioco gestore(0);

    // creo il menu iniziale
    MenuIniziale menu(0);

    return EXIT_SUCCESS;
}