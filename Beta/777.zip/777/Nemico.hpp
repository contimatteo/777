//
// Created by Matteo Conti on 25/06/17.
//

#ifndef INC_777_NEMICO_HPP
#define INC_777_NEMICO_HPP

#include "ElementoGrafico.hpp"

class Nemico : ElementoGrafico
{
    
};


#endif //INC_777_NEMICO_HPP
