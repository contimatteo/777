//
// Created by Matteo Conti on 26/06/17.
//

#ifndef INC_777_ELEMENTOGRAFICO_HPP
#define INC_777_ELEMENTOGRAFICO_HPP

#include <SFML/Graphics/RectangleShape.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

class ElementoGrafico
{
    public:
        template<typename Object>
        static void disegnaElemento(RenderWindow &window, Object &element);

        static void disegnaElemento(RenderWindow &window, RectangleShape &element);
        static void disegnaElemento(RenderWindow &window, Sprite &element);
};


#endif //INC_777_ELEMENTOGRAFICO_HPP
