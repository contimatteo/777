//
// Created by Matteo Conti on 25/06/17.
//

#include<iostream>
#include <SFML/Graphics/RectangleShape.hpp>
#include <SFML/Graphics.hpp>
#include "GestoreGioco.hpp"
#include "ElementoGrafico.hpp"

//********************************************************************************************
//********************************************************************************************

RectangleShape rettangoloSceltaa;

//********************************************************************************************
//********************************************************************************************

void GestoreGioco::creaGioco()
{
    // elemento di prova
    rettangoloSceltaa.setSize(Vector2f(400, 100));
    rettangoloSceltaa.setPosition(10, 10);
    rettangoloSceltaa.setFillColor(Color::Red);
    ElementoGrafico::disegnaElemento(Gioco, rettangoloSceltaa);
    // eseguo il gioco finchè la finestra rimane aperta
    while (Gioco.isOpen()) {
        // sincronizzo il frame-rate del gioco con quello dello schermo
        Gioco.setVerticalSyncEnabled(true);
        // catturo tutti gli eventi verificatosi durante l'esecuzione del gioco fino all'ultimo loop
        Event evento;
        while (Gioco.pollEvent(evento)) {
            // controllo che la finestra del gioco non venga ridimensionata
            if (evento.type == sf::Event::Resized) {
                const Vector2u dimensioni = Vector2u(1200, 1200);
                Gioco.setSize(dimensioni);
            }
            // controllo quando la finestra viene chiusa --> chiudo il gioco
            if (Event::Closed == evento.type) {
                Gioco.close();
                MenuInizialeGioco->setVisible(true);
            }
        }
    }
}

// cosruttore
GestoreGioco::GestoreGioco(int scelta, RenderWindow &menu)
{
    // copio l'istanza del menu iniziale nella variabile globale Menu
    MenuInizialeGioco=&menu;

    switch(scelta)
    {
        // GIOCA
        case 1:
            Gioco.create(VideoMode(500, 500), "777 - GIOCA");
            Gioco.setKeyRepeatEnabled(true);
            rettangoloSceltaa.setPosition(10, 10);
            creaGioco();
            std::cout<<"GIOCA \n";
            break;

        // TUTORIAL
        case 2:
            std::cout<<"TUTORIAL \n";
            Tutorial.create(VideoMode(1200, 1200), "777 - TUTORIAL");
            Tutorial.setKeyRepeatEnabled(true);
            Tutorial.close();
            break;

        // GIOCA
        case 3:
            std::cout<<"INFO \n";
            Info.create(VideoMode(1200, 1200), "777 - INFO");
            Info.setKeyRepeatEnabled(true);
            Info.close();
            break;


        // scelta non inesistente
        default:
            break;
    }
}

//********************************************************************************************
