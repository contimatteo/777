//
// Created by Mattia_Porcelli on 04/10/2017.
//

#ifndef INC_777_MAPPA_HPP
#define INC_777_MAPPA_HPP

class Mappa{

    public:
    int location[20][20];



    private:
    int numero_di_nemici = 0;



};
#endif //INC_777_MAPPA_HPP
