//
// Created by enrico on 21-Jun-17.
//

#ifndef INC_777_NEMICO_H
#define INC_777_NEMICO_H

class Nemico{

private:
    int attacco;
    int x;
    int y;
public:

    int setAttacco(int nuovoAttacco);
    int setX(int xNuova);
    int setY (int yNuova);



};

#endif //INC_777_NEMICO_H
