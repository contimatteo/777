//
// Created by Matteo Conti on 10/10/17.
//

#include "Utilities.hpp"

 const int Utilities::DIMENSIONE_CELLE = 20;
 const int Utilities::ALTEZZA_FINESTRA_GIOCO = 1200;
 const int Utilities::LARGHEZZA_FINESTRA_GIOCO = 1200;
 const int Utilities::NUMERO_CASELLE_ASSE_X=60;
 const int Utilities::NUMERO_CASELLE_ASSE_Y=60;