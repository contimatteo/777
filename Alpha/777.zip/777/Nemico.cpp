#include "Nemico.hpp"
#include <iostream>

    //ABLITA IN SOSPESO.


    int Nemico::setAttacco(int nuovoAttacco) {attacco = nuovoAttacco;}
    int Nemico::setX(int xNuova) { x = xNuova; }
    int Nemico::setY (int yNuova) { y = yNuova;}

