//
// Created by Matteo Conti on 10/10/17.
//

#ifndef INC_777_UTILITIES_HPP
#define INC_777_UTILITIES_HPP


class Utilities
{
    public:
        static const int DIMENSIONE_CELLE;
        static const int ALTEZZA_FINESTRA_GIOCO;
        static const int LARGHEZZA_FINESTRA_GIOCO;
        static const int NUMERO_CASELLE_ASSE_X;
        static const int NUMERO_CASELLE_ASSE_Y;


};


#endif //INC_777_UTILITIES_HPP
